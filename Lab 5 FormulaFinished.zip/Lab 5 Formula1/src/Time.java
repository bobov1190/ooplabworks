public class Time implements Comparable<Time> {

    private int hours, min, sec, cent;

    public Time(int hours, int min, int sec, int cent) {
        this.hours = hours;
        this.min = min;
        this.sec = sec;
        this.cent = cent;
    }

    @Override
    public String toString(){
        return hours + ":" + min + ":" + sec + "." + cent;
    }

    @Override
    public int compareTo(Time other) {
        if (this.hours != other.hours) {
            return Integer.compare(this.hours, other.hours);
        }
        if (this.min != other.min) {
            return Integer.compare(this.min, other.min);
        }
        if (this.sec != other.sec) {
            return Integer.compare(this.sec, other.sec);
        }
        return Integer.compare(this.cent, other.cent);
    }
}