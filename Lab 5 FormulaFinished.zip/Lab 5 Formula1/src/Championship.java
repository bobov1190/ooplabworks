import java.util.*;
import java.util.stream.Collectors;

public class Championship {

    private Map<String, Driver> drivers = new HashMap<>();
    private Map<String, GP> gps = new HashMap<>();

    public Driver createDriver(String name) {
        Driver d = new Driver(name);
        drivers.put(name, d);
        return d;
    }

    /**
     * @return the list of Drivers
     */

    public Collection<Driver> getDrivers() {
        return drivers.values();
    }

    /**
     * @param driver's name
     * @return the corresponding Driver object
     */

    public Driver getDriver(String name) {
        return drivers.get(name);
    }

    /**
     * @param GP name (Es. "Monza")
     * @return the corresponding GP object
     */

    public GP defineGrandPrix(String name) {
        GP gp = new GP(name);
        gps.put(name, gp);
        return gp;
    }

    /**
     * @param GP name
     * @return the corresponding GP object
     */

    public GP getGrandPrix(String name) {
        return gps.get(name);
    }

    public Time setTime(GP gp, Driver d, int hours, int min, int sec, int cent) {
        Time t = new Time(hours, min, sec, cent);
        gp.setDriverTime(d, t);
        d.addGP(gp);
        return t;
    }

    /**
     * @return drivers ranking sorted according to their points
     */

    public List<Driver> getChampionshipRanking() {
        Map<Integer, Driver> driverList = new TreeMap<>(Collections.reverseOrder());
        for (Driver d : drivers.values()) {
            driverList.put(d.getPoints(), d);
        }

        List<Driver> result = new LinkedList<>(driverList.values());
        return result;

//        return drivers.values().stream()
//                .sorted(Comparator.comparingInt(Driver::getPoints).reversed())
//                .collect(Collectors.toList());
    }

}