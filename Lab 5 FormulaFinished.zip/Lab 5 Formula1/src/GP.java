import java.util.*;
import java.util.stream.Collectors;

public class GP {

    private String name;
    private final Map<Time, Driver> driverTimes = new TreeMap<>();

    public GP(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    void setDriverTime(Driver driver, Time time) {
        driverTimes.put(time, driver);
    }

    /**
     * @return list of Driver Objects sorted in ascending way according to the race time
     */

    public List<Driver> getGPRanking() {
        List<Driver> result = new ArrayList<>();
        // TreeMap is already sorted by Time keys (ascending)
        for (Map.Entry<Time, Driver> entry : driverTimes.entrySet()) {
            result.add(entry.getValue());
        }
        return result;




//        return driverTimes.entrySet().stream()
//                .sorted(Comparator.comparing(Map.Entry::getValue))
//                .map(Map.Entry::getKey)
//                .collect(Collectors.toList());
    }

    /**
     * @param Driver Object
     * @return ranking (starting from 1)
     */

    public int getPosition(Driver driver) {
        List<Driver> ranking = getGPRanking();
        int index = ranking.indexOf(driver);
        return (index >= 0) ? index + 1 : 0;
    }

}