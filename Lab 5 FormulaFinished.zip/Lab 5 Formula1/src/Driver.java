import java.util.*;

public class Driver {

    private final String name;
    private final Set<GP> raced = new HashSet<>();

    public Driver(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    void addGP(GP gp) {
        raced.add(gp);
    }

    /**
     * @return List of raced GPs
     */

    public Collection<GP> getRaced() {
        return raced;
    }

    public int getPoints() {
        int total = 0;
        for (GP gp : raced) {
            int pos = gp.getPosition(this);
            total += getPointsForPosition(pos);
        }
        return total;
    }

    private int getPointsForPosition(int pos) {
        switch (pos) {
            case 1: return 25;
            case 2: return 18;
            case 3: return 15;
            case 4: return 12;
            case 5: return 10;
            case 6: return 8;
            case 7: return 6;
            case 8: return 4;
            case 9: return 2;
            case 10: return 1;
            default: return 0;
        }
    }

}