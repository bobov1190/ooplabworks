public class Person {
    private String first;
    private String last;
    private String ssn;
    private Doctor doctor;

    public Person(String first, String last, String ssn) {
        this.first = first;
        this.last = last;
        this.ssn = ssn;
        this.doctor = null;
    }

    public String getFirst() {
        return first;
    }

    public String getLast() {
        return last;
    }

    public String getSSN() {
        return ssn;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
}