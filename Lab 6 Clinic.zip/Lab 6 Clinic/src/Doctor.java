import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Doctor extends Person {
    private int id;
    private String specialization;
    private List<Person> patients;

    public Doctor(String first, String last, String ssn, int id, String specialization) {
        super(first, last, ssn);
        this.id = id;
        this.specialization = specialization;
        this.patients = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getSpecialization() {
        return specialization;
    }

    public Collection<Person> getPatients() {
        return patients;
    }

    void addPatient(Person p) {
        patients.add(p);
    }

    void removePatient(Person p) {
        patients.remove(p);
    }
}