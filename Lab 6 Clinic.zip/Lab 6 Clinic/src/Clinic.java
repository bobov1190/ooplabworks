import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Clinic {
    private HashMap<String, Person> persons;
    private HashMap<Integer, Doctor> doctors;

    public Clinic() {
        persons = new HashMap<String, Person>();
        doctors = new HashMap<Integer, Doctor>();
    }

    public void addPatient(String first, String last, String ssn) {
        Person p = new Person(first, last, ssn);
        persons.put(ssn, p);
    }

    public void addDoctor(String first, String last, String ssn, int id, String specialization) {
        Doctor d = new Doctor(first, last, ssn, id, specialization);
        persons.put(ssn, d);
        doctors.put(id, d);
    }

    public Person getPatient(String ssn) throws NoSuchPatient {
        Person p = persons.get(ssn);
        if (p == null) {
            throw new NoSuchPatient();
        }
        return p;
    }

    public Doctor getDoctor(int id) throws NoSuchDoctor {
        Doctor d = doctors.get(id);
        if (d == null) {
            throw new NoSuchDoctor();
        }
        return d;
    }

    public void assignPatientToDoctor(String ssn, int docId) throws NoSuchPatient, NoSuchDoctor {
        Person p = getPatient(ssn);
        Doctor d = getDoctor(docId);
        Doctor oldDoc = p.getDoctor();
        if (oldDoc != null && oldDoc != d) {
            oldDoc.removePatient(p);
        }
        p.setDoctor(d);
        d.addPatient(p);
    }

    public void loadData(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = br.readLine()) != null) {
            try {
                String[] parts = line.split(";");
                if (parts.length < 1) continue;

                if (parts[0].equals("P")) {
                    if (parts.length == 4) {
                        addPatient(parts[1], parts[2], parts[3]);
                    }
                } else if (parts[0].equals("M")) {
                    if (parts.length == 6) {
                        int id = Integer.parseInt(parts[1]);
                        addDoctor(parts[2], parts[3], parts[4], id, parts[5]);
                    }
                }
            } catch (Exception e) {
                continue;
            }
        }
        br.close();
    }

    public Collection<Doctor> idleDoctors() {
        List<Doctor> idle = new ArrayList<Doctor>();
        for (Doctor d : doctors.values()) {
            if (d.getPatients().size() == 0) {
                idle.add(d);
            }
        }
        Collections.sort(idle, new Comparator<Doctor>() {
            public int compare(Doctor a, Doctor b) {
                return a.getFirst().compareTo(b.getFirst());
            }
        });
        return idle;
    }

    public Collection<Doctor> busyDoctors() {
        int totalPatients = 0;
        int numDocs = doctors.size();
        for (Doctor d : doctors.values()) {
            totalPatients += d.getPatients().size();
        }
        double avg = numDocs > 0 ? (double) totalPatients / numDocs : 0;

        List<Doctor> busy = new ArrayList<Doctor>();
        for (Doctor d : doctors.values()) {
            if (d.getPatients().size() > avg) {
                busy.add(d);
            }
        }
        Collections.sort(busy, new Comparator<Doctor>() {
            public int compare(Doctor a, Doctor b) {
                return a.getFirst().compareTo(b.getFirst());
            }
        });
        return busy;
    }

    public Collection<String> doctorsByNumPatients() {
        List<Doctor> all = new ArrayList<Doctor>(doctors.values());
        Collections.sort(all, new Comparator<Doctor>() {
            public int compare(Doctor a, Doctor b) {
                int na = a.getPatients().size();
                int nb = b.getPatients().size();
                if (na != nb) {
                    return nb - na;
                }
                int lastComp = a.getLast().compareTo(b.getLast());
                if (lastComp != 0) {
                    return lastComp;
                }
                return a.getFirst().compareTo(b.getFirst());
            }
        });

        List<String> res = new ArrayList<String>();
        for (Doctor d : all) {
            res.add(String.format("%3d: %s %s", d.getPatients().size(), d.getFirst(), d.getLast()));
        }
        return res;
    }

    public Collection<String> countPatientsPerSpecialization() {
        HashMap<String, Integer> countMap = new HashMap<String, Integer>();
        for (Doctor d : doctors.values()) {
            String spec = d.getSpecialization();
            int num = d.getPatients().size();
            if (countMap.containsKey(spec)) {
                countMap.put(spec, countMap.get(spec) + num);
            } else {
                countMap.put(spec, num);
            }
        }

        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(countMap.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                int ca = a.getValue();
                int cb = b.getValue();
                if (ca != cb) {
                    return cb - ca;
                }
                return a.getKey().compareTo(b.getKey());
            }
        });

        List<String> res = new ArrayList<String>();
        for (Map.Entry<String, Integer> e : list) {
            res.add(String.format("%3d %s", e.getValue(), e.getKey()));
        }
        return res;
    }
}